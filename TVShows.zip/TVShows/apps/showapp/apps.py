from django.apps import AppConfig


class ShowappConfig(AppConfig):
    name = 'showapp'
